document.addEventListener('DOMContentLoaded', () => {
    const serverStatus = document.getElementById('server-status');
    const botStatus = document.getElementById('bot-status');
    const toggleBtn = document.getElementById('toggle-btn');
    const profitDisplay = document.getElementById('profit-display');
    const resetBtn = document.getElementById('reset-btn');
    
    const inputs = {
        baseStake: document.getElementById('base-stake'),
        takeProfit: document.getElementById('tp-limit'),
        stopLoss: document.getElementById('sl-limit'),
        maxLossStreak: document.getElementById('max-streak-limit'),
        chatId: document.getElementById('chat-id-input'),
        bettingMode: document.getElementById('betting-mode')
    };
    
    let isRunning = false;

    chrome.storage.local.get(['botEnabled', 'baseStake', 'takeProfit', 'stopLoss', 'maxLossStreak', 'chatId', 'totalProfit', 'bettingMode'], (res) => {
        isRunning = !!res.botEnabled;
        if (res.baseStake) inputs.baseStake.value = res.baseStake;
        if (res.takeProfit) inputs.takeProfit.value = res.takeProfit;
        if (res.stopLoss) inputs.stopLoss.value = res.stopLoss;
        if (res.maxLossStreak) inputs.maxLossStreak.value = res.maxLossStreak;
        if (res.chatId) inputs.chatId.value = res.chatId;
        if (res.bettingMode) inputs.bettingMode.value = res.bettingMode;
        
        updateProfitUI(res.totalProfit || 0);
        updateUI();
    });

    Object.keys(inputs).forEach(key => {
        inputs[key].addEventListener('change', (e) => {
            let val = e.target.value;
            if (e.target.type === 'number') val = parseFloat(val) || 0;
            chrome.storage.local.set({ [key]: val });
        });
    });

    resetBtn.addEventListener('click', () => {
        chrome.storage.local.set({ totalProfit: 0, pendingBet: null, winStreak: 0, maxWinStreak: 0, maxLossStreakRec: 0, localLossStreak: 0 });
        updateProfitUI(0);
    });

    toggleBtn.addEventListener('click', () => {
        isRunning = !isRunning;
        if (isRunning) {
            chrome.storage.local.set({ botEnabled: true, localLossStreak: 0 });
        } else {
            chrome.storage.local.set({ botEnabled: false });
        }
        updateUI();
    });

    function updateProfitUI(amount) {
        profitDisplay.textContent = amount >= 0 ? `+₦${amount.toFixed(2)}` : `-₦${Math.abs(amount).toFixed(2)}`;
        profitDisplay.style.color = amount > 0 ? '#4ade80' : amount < 0 ? '#f87171' : '#fbbf24';
    }

    function updateUI() {
        if (isRunning) {
            toggleBtn.textContent = "STOP AUTO-BET (KILL SWITCH)";
            toggleBtn.className = "btn btn-stop";
            botStatus.textContent = "Bot: ARMED 🟢";
        } else {
            toggleBtn.textContent = "ENABLE AUTO-BET";
            toggleBtn.className = "btn btn-start";
            botStatus.textContent = "Bot: OFF 🔴";
        }
    }

    setInterval(async () => {
        chrome.storage.local.get(['totalProfit', 'botEnabled', 'baseStake', 'takeProfit', 'stopLoss', 'bettingMode'], (res) => {
            updateProfitUI(res.totalProfit || 0);
            
            if (isRunning !== !!res.botEnabled) {
                isRunning = !!res.botEnabled;
                updateUI();
            }
            if (res.baseStake && parseFloat(inputs.baseStake.value) !== res.baseStake) inputs.baseStake.value = res.baseStake;
            if (res.takeProfit && parseFloat(inputs.takeProfit.value) !== res.takeProfit) inputs.takeProfit.value = res.takeProfit;
            if (res.stopLoss && parseFloat(inputs.stopLoss.value) !== res.stopLoss) inputs.stopLoss.value = res.stopLoss;
            if (res.bettingMode && inputs.bettingMode.value !== res.bettingMode) inputs.bettingMode.value = res.bettingMode;
        });

        try {
            // CLOUD UPDATE: Changed from localhost to VPS IP
            await fetch('http://78.47.19.148:5000/get_bets');
            serverStatus.textContent = "🟢 Server Linked";
            serverStatus.style.color = "#00ff00";
        } catch (e) {
            serverStatus.textContent = "🔴 Python Disconnected";
            serverStatus.style.color = "#ff4444";
        }
    }, 2000);
});