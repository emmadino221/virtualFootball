// =====================================================================
// CONFIGURATION
// =====================================================================
let isBusy = false;
const MARTINGALE_MULTIPLIER = 2.54; 
const SELECTORS = {
    currentWeek: "#leagueWeekNumber",                
    overUnderTab: "a[data-value='Over_Under_1_5'], li[data-value='Over_Under_1_5'] a",
    matchResultTab: "a[data-value='Match_Result'], a[data-value='1X2'], li[data-value='Match_Result'] a",  
    goalNoGoalTab: "a[data-value='GoalGoal_NoGoal'], li[data-value='GoalGoal_NoGoal'] a", 
    tableRow: "tr",                                  
    over15Checkbox: "label[for$='_over']",           
    stakeInput: "#inputAmount",                      
    placeBetBtn: "#button_bet",                      
    confirmBetBtn: "#button_bet_ticket",             
    closeTicketBtn: "#button_sent-ticket-close"      
};

const POLLING_INTERVAL_MS = 3000;
let lastBetWeek = null;

// =====================================================================
// OVERLAY SYSTEM
// =====================================================================
function createOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'bet-automation-overlay';
    overlay.innerHTML = `
        <div class="overlay-header">
            <div class="overlay-title">🤖 Auto-Bet <span id="overlay-running-profit" style="margin-left: 8px; padding: 2px 6px; border-radius: 4px; background: rgba(0,0,0,0.3); color: #fbbf24; font-size:12px;">₦0.00</span></div>
            <div class="overlay-controls"><button id="overlay-minimize">−</button><button id="overlay-close">✕</button></div>
        </div>
        <div class="overlay-content">
            <div class="status-section"><div class="status-label">Status:</div><div class="status-value" id="status-text">Idle</div></div>
            <div class="week-section"><div class="week-label">Current Week:</div><div class="week-value" id="week-text">-</div></div>
            <div class="matches-section"><div class="matches-label">Targets:</div><div class="matches-list" id="matches-list"></div></div>
            <div class="stats-section"><div id="stats-log"></div></div>
            <div class="financials-section">
                <div class="fin-row"><span>Total Odds:</span> <span id="overlay-odds">0.00</span></div>
                <div class="fin-row"><span>Stake:</span> <span id="overlay-stake">₦0.00</span></div>
                <div class="fin-row" style="color: #4ade80;"><span>Est. Return:</span> <span id="overlay-return">₦0.00</span></div>
            </div>
        </div>
    `;
    
    const style = document.createElement('style');
    style.textContent = `
        #bet-automation-overlay { position: fixed; bottom: 20px; right: 20px; width: 380px; height: 460px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 12px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3); z-index: 999999; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; color: white; display: flex; flex-direction: column; resize: both; overflow: hidden; user-select: none; cursor: grab; }
        #bet-automation-overlay.minimized .overlay-content { display: none; }
        .overlay-header { background: rgba(0, 0, 0, 0.2); padding: 12px 16px; display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid rgba(255, 255, 255, 0.2); cursor: grab; flex-shrink: 0; }
        .overlay-header:active { cursor: grabbing; }
        .overlay-title { font-size: 14px; font-weight: 600; letter-spacing: 0.5px; display: flex; align-items: center;}
        .overlay-controls { display: flex; gap: 8px; }
        .overlay-controls button { background: rgba(255, 255, 255, 0.2); border: none; color: white; width: 28px; height: 28px; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: bold; transition: all 0.2s ease; display: flex; align-items: center; justify-content: center; }
        .overlay-controls button:hover { background: rgba(255, 255, 255, 0.35); transform: scale(1.1); }
        .overlay-content { flex: 1; overflow-y: auto; padding: 14px 16px; display: flex; flex-direction: column; gap: 12px; }
        .overlay-content::-webkit-scrollbar { width: 6px; }
        .overlay-content::-webkit-scrollbar-track { background: rgba(255, 255, 255, 0.1); border-radius: 10px; }
        .overlay-content::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.3); border-radius: 10px; }
        .status-section, .week-section, .matches-section, .stats-section { background: rgba(255, 255, 255, 0.1); padding: 10px 12px; border-radius: 8px; border-left: 3px solid rgba(255, 255, 255, 0.3); }
        .status-section { border-left-color: #4ade80; }
        .status-label, .week-label, .matches-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; opacity: 0.8; margin-bottom: 4px; }
        .status-value { font-size: 13px; font-weight: 500; padding: 4px 8px; background: rgba(74, 222, 128, 0.2); border-radius: 4px; display: inline-block; }
        .week-value { font-size: 14px; font-weight: 600; color: #fbbf24; }
        .matches-list { display: flex; flex-direction: column; gap: 6px; font-size: 12px; }
        .match-item { background: rgba(255, 255, 255, 0.15); padding: 6px 8px; border-radius: 6px; border-left: 2px solid #4ade80; animation: slideIn 0.3s ease; display: flex; justify-content: space-between; }
        @keyframes slideIn { from { opacity: 0; transform: translateX(-10px); } to { opacity: 1; transform: translateX(0); } }
        .match-item.success { border-left-color: #4ade80; background: rgba(74, 222, 128, 0.15); }
        .match-item.error { border-left-color: #f87171; background: rgba(248, 113, 113, 0.15); }
        #stats-log { font-size: 11px; line-height: 1.5; opacity: 0.9; }
        .log-entry { padding: 3px 0; border-bottom: 1px solid rgba(255, 255, 255, 0.1); }
        .log-entry:last-child { border-bottom: none; }
        .financials-section { background: rgba(0, 0, 0, 0.25); padding: 10px 12px; border-radius: 8px; margin-top: auto; font-size: 13px; font-weight: 600; display: flex; flex-direction: column; gap: 6px; border: 1px solid rgba(255,255,255,0.1);}
        .fin-row { display: flex; justify-content: space-between; align-items: center; }
    `;
    
    document.head.appendChild(style);
    document.body.appendChild(overlay);
    makeElementDraggable(overlay);
    document.getElementById('overlay-minimize').addEventListener('click', () => { overlay.classList.toggle('minimized'); });
    document.getElementById('overlay-close').addEventListener('click', () => { overlay.style.display = 'none'; });
    return overlay;
}

function makeElementDraggable(element) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    const header = element.querySelector('.overlay-header');
    header.onmousedown = (e) => {
        e.preventDefault();
        pos3 = e.clientX; pos4 = e.clientY;
        document.onmouseup = () => { document.onmouseup = null; document.onmousemove = null; };
        document.onmousemove = (e) => {
            e.preventDefault();
            pos1 = pos3 - e.clientX; pos2 = pos4 - e.clientY;
            pos3 = e.clientX; pos4 = e.clientY;
            element.style.top = (element.offsetTop - pos2) + "px";
            element.style.left = (element.offsetLeft - pos1) + "px";
            element.style.bottom = 'auto'; element.style.right = 'auto';
        };
    };
}

function updateOverlayStatus(text, type = 'info') {
    try {
        const statusEl = document.getElementById('status-text');
        if (statusEl) {
            statusEl.textContent = text;
            statusEl.style.background = type === 'success' ? 'rgba(74, 222, 128, 0.3)' : type === 'error' ? 'rgba(248, 113, 113, 0.3)' : 'rgba(59, 130, 246, 0.3)';
        }
    } catch (e) { }
}
function updateOverlayWeek(week) { try { const weekEl = document.getElementById('week-text'); if (weekEl) weekEl.textContent = week; } catch (e) { } }
function updateOverlayTotalProfit(amount) {
    try {
        const profitEl = document.getElementById('overlay-running-profit');
        if (profitEl) {
            profitEl.textContent = amount >= 0 ? `+₦${amount.toFixed(2)}` : `-₦${Math.abs(amount).toFixed(2)}`;
            profitEl.style.color = amount > 0 ? '#4ade80' : amount < 0 ? '#f87171' : '#fbbf24';
        }
    } catch (e) {}
}
function addMatchToOverlay(home, away, odds, status = 'success') {
    try {
        const matchList = document.getElementById('matches-list');
        if (!matchList) return;
        const matchItem = document.createElement('div');
        matchItem.className = `match-item ${status}`;
        matchItem.innerHTML = `<span>${status === 'success' ? '✅' : '❌'} ${home} vs ${away}</span> <span style="color:#fbbf24; font-weight:bold;">${odds}</span>`;
        matchList.appendChild(matchItem);
        while (matchList.children.length > 5) matchList.removeChild(matchList.firstChild);
    } catch (e) { }
}
function updateFinancials(odds, stake, expectedReturn, pureProfit) {
    try {
        document.getElementById('overlay-odds').textContent = odds;
        document.getElementById('overlay-stake').textContent = `₦${stake}`;
        document.getElementById('overlay-return').innerHTML = `₦${expectedReturn} <span style="font-size:11px; opacity:0.8;">(+₦${pureProfit})</span>`;
    } catch (e) { }
}
function addLogEntry(text) {
    try {
        const logEl = document.getElementById('stats-log');
        if (!logEl) return;
        const entry = document.createElement('div');
        entry.className = 'log-entry';
        entry.textContent = text;
        logEl.insertBefore(entry, logEl.firstChild);
        while (logEl.children.length > 6) logEl.removeChild(logEl.lastChild);
    } catch (e) { }
}

window.addEventListener('load', () => {
    createOverlay();
    updateOverlayStatus('Ready', 'info');
    chrome.storage.local.get(['totalProfit'], (res) => updateOverlayTotalProfit(res.totalProfit || 0));
});

function getIframeDoc() {
    const iframe = document.querySelector('iframe');
    return iframe ? iframe.contentDocument : document;
}

// ---------------------------------------------------------------------
// TELEGRAM COMMAND SYNC PIPELINE
// ---------------------------------------------------------------------
async function fetchAIData() {
    try {
        const st = await chrome.storage.local.get(['botEnabled', 'baseStake', 'takeProfit', 'stopLoss', 'totalProfit', 'bettingMode']);
        const currentMode = st.bettingMode || 'OU';
        
        // CLOUD UPDATE: Changed from localhost to VPS IP
        const response = await fetch('http://78.47.19.148:5000/sync', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                botEnabled: !!st.botEnabled,
                baseStake: st.baseStake || 100,
                takeProfit: st.takeProfit || 0,
                stopLoss: st.stopLoss || 0,
                totalProfit: st.totalProfit || 0,
                bettingMode: currentMode
            })
        });
        const data = await response.json();

        if (data.commands && data.commands.length > 0) {
            for (const cmd of data.commands) {
                if (cmd.type === 'STOP') {
                    await chrome.storage.local.set({ botEnabled: false });
                    updateOverlayStatus('🛑 STOPPED', 'error');
                    addLogEntry('📱 Remote: Bot Stopped');
                } else if (cmd.type === 'START') {
                    await chrome.storage.local.set({ botEnabled: true, localLossStreak: 0 }); 
                    updateOverlayStatus('🟢 STARTED', 'success');
                    addLogEntry('📱 Remote: Bot Started (Streak Reset)');
                } else if (cmd.type === 'STAKE') {
                    await chrome.storage.local.set({ baseStake: cmd.value });
                    addLogEntry(`📱 Remote: Stake ₦${cmd.value}`);
                } else if (cmd.type === 'TP') {
                    await chrome.storage.local.set({ takeProfit: cmd.value });
                    addLogEntry(`📱 Remote: Take Profit ₦${cmd.value}`);
                } else if (cmd.type === 'SL') {
                    await chrome.storage.local.set({ stopLoss: cmd.value });
                    addLogEntry(`📱 Remote: Stop Loss -₦${cmd.value}`);
                } else if (cmd.type === 'RESET') {
                    await chrome.storage.local.set({ totalProfit: 0, pendingBet: null, winStreak: 0, maxWinStreak: 0, maxLossStreakRec: 0, localLossStreak: 0 });
                    updateOverlayTotalProfit(0);
                    addLogEntry('📱 Remote: Hard Reset Executed');
                } else if (cmd.type === 'MODE') {
                    await chrome.storage.local.set({ bettingMode: cmd.value });
                    addLogEntry(`📱 Remote: Mode Switched to ${cmd.value}`);
                }
            }
        }

        const reCheck = await chrome.storage.local.get(['bettingMode']);
        const finalMode = reCheck.bettingMode || 'OU';
        
        let activeTargets = [];
        let activeStreak = 0;
        if (finalMode === 'OU') { activeTargets = data.targets_ou; activeStreak = data.loss_streak_ou; }
        else if (finalMode === '1X2') { activeTargets = data.targets_1x2; activeStreak = data.loss_streak_1x2; }
        else if (finalMode === 'GG') { activeTargets = data.targets_gg; activeStreak = data.loss_streak_gg; }

        return { targets: activeTargets || [], pythonLossStreak: activeStreak || 0, mode: finalMode };
    } catch (error) { return { targets: [], pythonLossStreak: 0, mode: 'OU' }; }
}

async function isWeekReady() {
    try {
        // CLOUD UPDATE: Changed from localhost to VPS IP
        const response = await fetch('http://78.47.19.148:5000/is_week_ready');
        const data = await response.json();
        return data.is_ready ? data.ready_week : null;
    } catch (error) { return null; }
}

function normalizeWeek(weekStr) {
    const match = weekStr.match(/(\d+)/);
    return match ? match[1] : weekStr;
}

function simulateHumanClick(element) {
    if (!element) return false;
    element.style.border = "2px solid #00ff00"; 
    element.dispatchEvent(new MouseEvent('click', { view: window, bubbles: true, cancelable: true }));
    element.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
    element.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
    return true;
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function triggerCircuitBreaker(reason) {
    await chrome.storage.local.set({ botEnabled: false });
    updateOverlayStatus(`🛑 STOPPED: ${reason}`, 'error');
    addLogEntry(`🛑 CIRCUIT BREAKER TRIGGERED`);
}

// ---------------------------------------------------------------------
// EXECUTION & P&L RESOLUTION
// ---------------------------------------------------------------------
async function executeBets(payload) {
    const targets = payload.targets;
    const pythonLossStreak = payload.pythonLossStreak; 
    const targetMode = payload.mode; 

    if (targets.length === 0) return;

    let conf = { baseStake: 100, takeProfit: 5000, stopLoss: 10000, maxLossStreak: 5, chatId: "" };
    try {
        const storage = await chrome.storage.local.get(['botEnabled', 'baseStake', 'takeProfit', 'stopLoss', 'maxLossStreak', 'chatId']);
        if (!storage.botEnabled) return; 
        if (storage.baseStake) conf.baseStake = parseFloat(storage.baseStake);
        if (storage.takeProfit) conf.takeProfit = parseFloat(storage.takeProfit);
        if (storage.stopLoss) conf.stopLoss = parseFloat(storage.stopLoss);
        if (storage.maxLossStreak) conf.maxLossStreak = parseInt(storage.maxLossStreak);
        if (storage.chatId) conf.chatId = storage.chatId;
    } catch (e) { return; }

    const doc = getIframeDoc();
    const weekEl = doc.querySelector(SELECTORS.currentWeek);
    if (!weekEl) return;
    const currentWeekStr = weekEl.innerText.trim();
    
    if (currentWeekStr !== lastBetWeek) {
        updateOverlayStatus('Waiting for backend...', 'info');
        try {
            const readyWeek = await isWeekReady();
            const normalizedReady = readyWeek ? normalizeWeek(readyWeek) : null;
            const normalizedCurrent = normalizeWeek(currentWeekStr);
            if (!normalizedReady || normalizedReady !== normalizedCurrent) return;
        } catch (e) { return; }
        
        const st = await chrome.storage.local.get(['pendingBet', 'totalProfit', 'winStreak', 'maxWinStreak', 'maxLossStreakRec', 'localLossStreak']);
        let currentTotal = st.totalProfit || 0;
        let wStrk = st.winStreak || 0;
        let mWStrk = st.maxWinStreak || 0;
        let mLStrk = st.maxLossStreakRec || 0;
        let currentLocalStreak = st.localLossStreak || 0; 

        if (st.pendingBet) {
            let resStr = "LOSS";
            if (pythonLossStreak === 0) { 
                currentTotal += st.pendingBet.profit;
                addLogEntry(`✅ Previous Bet Won! +₦${st.pendingBet.profit.toFixed(2)}`);
                resStr = "WIN";
                wStrk++;
                if (wStrk > mWStrk) mWStrk = wStrk;
                currentLocalStreak = 0; 
            } else { 
                currentTotal -= st.pendingBet.stake;
                addLogEntry(`❌ Previous Bet Lost! -₦${st.pendingBet.stake.toFixed(2)}`);
                resStr = "LOSS";
                wStrk = 0;
                currentLocalStreak++; 
                if (currentLocalStreak > mLStrk) mLStrk = currentLocalStreak;
            }
            
            await chrome.storage.local.set({ 
                totalProfit: currentTotal, 
                pendingBet: null, 
                winStreak: wStrk, 
                maxWinStreak: mWStrk, 
                maxLossStreakRec: mLStrk,
                localLossStreak: currentLocalStreak 
            });
            updateOverlayTotalProfit(currentTotal);

            if (conf.chatId) {
                // CLOUD UPDATE: Changed from localhost to VPS IP
                fetch('http://78.47.19.148:5000/send_receipt', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        chat_id: conf.chatId, result: resStr, stake: st.pendingBet.stake, profit: st.pendingBet.profit, net_profit: currentTotal, win_streak: wStrk, loss_streak: currentLocalStreak, max_win_streak: mWStrk, max_loss_streak: mLStrk
                    })
                }).catch(e => console.log("Telegram Receipt Error:", e));
            }
        }

        document.getElementById('matches-list').innerHTML = '';
        updateFinancials("0.00", "0.00", "0.00", "0.00");
        
        if (currentTotal >= conf.takeProfit && conf.takeProfit > 0) { await triggerCircuitBreaker(`Take Profit (+₦${conf.takeProfit}) Reached`); return; }
        if (currentTotal <= -Math.abs(conf.stopLoss) && conf.stopLoss > 0) { await triggerCircuitBreaker(`Stop Loss (-₦${conf.stopLoss}) Reached`); return; }
        
        if (currentLocalStreak >= conf.maxLossStreak && conf.maxLossStreak > 0) { await triggerCircuitBreaker(`Max Loss Streak (${conf.maxLossStreak}) Reached`); return; }

        updateOverlayStatus(`Backend Ready (${targetMode})`, 'success');
        updateOverlayWeek(currentWeekStr);
    }
    
    if (currentWeekStr === lastBetWeek) return; 

    updateOverlayStatus('Processing...', 'info');

    let dataLoaded = false;
    for(let i = 0; i < 10; i++) {
        const rows = doc.querySelectorAll(SELECTORS.tableRow);
        if (rows.length > 5) { dataLoaded = true; break; }
        await sleep(1000);
    }
    if (!dataLoaded) { updateOverlayStatus('Data load timeout', 'error'); return; }

    if (targetMode === 'OU') {
        const ouTab = doc.querySelector(SELECTORS.overUnderTab);
        if (ouTab) { simulateHumanClick(ouTab); await sleep(2500); }
    } else if (targetMode === '1X2') {
        const mrTab = doc.querySelector(SELECTORS.matchResultTab);
        if (mrTab) { simulateHumanClick(mrTab); await sleep(2500); }
    } else if (targetMode === 'GG') {
        const ggTab = doc.querySelector(SELECTORS.goalNoGoalTab);
        if (ggTab) { simulateHumanClick(ggTab); await sleep(2500); }
    }

    const rows = doc.querySelectorAll(SELECTORS.tableRow);
    let selectedCount = 0;
    const expectedCount = targetMode === 'OU' ? 3 : 1;
    let scrapedTotalOdds = 1.0;

    for (const row of rows) {
        if (selectedCount >= expectedCount) break;
        const textContent = row.innerText.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
        
        for (const target of targets) {
            if (textContent.includes(target.home_team) && textContent.includes(target.away_team)) {
                
                if (targetMode === 'OU') {
                    const overBtn = row.querySelector(SELECTORS.over15Checkbox);
                    if (overBtn) {
                        const oddsText = overBtn.innerText || overBtn.textContent;
                        const oddsValue = parseFloat(oddsText.trim());
                        if (!isNaN(oddsValue)) scrapedTotalOdds *= oddsValue;

                        simulateHumanClick(overBtn);
                        selectedCount++;
                        addMatchToOverlay(target.home_team, target.away_team, (oddsValue || '?').toString(), 'success');
                        await sleep(2000); 
                    }
                } 
                
                else if (targetMode === '1X2') {
                    const inputs = row.querySelectorAll('input.checkbox_bets');
                    if (inputs.length >= 3) {
                        let targetInput;
                        if (target.prediction === "HOME") targetInput = inputs[0];
                        if (target.prediction === "DRAW") targetInput = inputs[1];
                        if (target.prediction === "AWAY") targetInput = inputs[2];
                        
                        if (targetInput) {
                            const label = row.querySelector(`label[for='${targetInput.id}']`);
                            if (label) {
                                const oddsText = label.innerText || label.textContent;
                                const oddsValue = parseFloat(oddsText.trim());
                                if (!isNaN(oddsValue)) scrapedTotalOdds *= oddsValue;

                                simulateHumanClick(label);
                                selectedCount++;
                                addMatchToOverlay(target.home_team, target.away_team, `[${target.prediction}] ` + (oddsValue || '?').toString(), 'success');
                                await sleep(2000);
                            }
                        }
                    }
                }
                
                else if (targetMode === 'GG') {
                    let targetLabelSelector = "";
                    if (target.prediction_gg === "GG") targetLabelSelector = "label[for$='_gg']";
                    if (target.prediction_gg === "NG") targetLabelSelector = "label[for$='_nog']";
                    
                    if (targetLabelSelector) {
                        const label = row.querySelector(targetLabelSelector);
                        if (label) {
                            const oddsText = label.innerText || label.textContent;
                            const oddsValue = parseFloat(oddsText.trim());
                            if (!isNaN(oddsValue)) scrapedTotalOdds *= oddsValue;

                            simulateHumanClick(label);
                            selectedCount++;
                            addMatchToOverlay(target.home_team, target.away_team, `[${target.prediction_gg}] ` + (oddsValue || '?').toString(), 'success');
                            await sleep(2000);
                        }
                    }
                }
            }
        }
    }

    if (selectedCount === expectedCount) {
        
        const localData = await chrome.storage.local.get(['localLossStreak']);
        const currentLocalStreakForMath = localData.localLossStreak || 0;
        
        const calculatedStake = conf.baseStake * Math.pow(MARTINGALE_MULTIPLIER, currentLocalStreakForMath);
        const finalStake = parseFloat(calculatedStake.toFixed(2));
        
        const expectedReturn = parseFloat((calculatedStake * scrapedTotalOdds).toFixed(2));
        const pureProfit = parseFloat((expectedReturn - calculatedStake).toFixed(2));

        updateFinancials(scrapedTotalOdds.toFixed(2), finalStake.toFixed(2), expectedReturn.toFixed(2), pureProfit.toFixed(2));

        updateOverlayStatus(`Placing Bet...`, 'info');
        addLogEntry(`💸 Math: ₦${conf.baseStake} x 2.54^${currentLocalStreakForMath}`);
        
        const stakeInput = doc.querySelector(SELECTORS.stakeInput);
        if (stakeInput) {
            stakeInput.value = finalStake;
            stakeInput.dispatchEvent(new Event('input', { bubbles: true }));
            await sleep(1000);
        }
        const betBtn = doc.querySelector(SELECTORS.placeBetBtn);
        if (betBtn) {
            simulateHumanClick(betBtn); 
            await sleep(1500); 
            const confirmBtn = doc.querySelector(SELECTORS.confirmBetBtn);
            if (confirmBtn) {
                simulateHumanClick(confirmBtn);
                await chrome.storage.local.set({ pendingBet: { stake: finalStake, profit: pureProfit, week: currentWeekStr } });
                await sleep(2000); 
                updateOverlayStatus('Bet Confirmed! ✅', 'success');
                addLogEntry(`💰 Placed: ₦${finalStake.toFixed(2)}`);
                const closeBtn = doc.querySelector(SELECTORS.closeTicketBtn);
                if (closeBtn) simulateHumanClick(closeBtn);
            }
        }
    } else {
        updateOverlayStatus(`Found ${selectedCount}/${expectedCount} matches`, 'error');
        addLogEntry('❌ Target missing or odds disabled');
    }

    lastBetWeek = currentWeekStr;
}

setInterval(async () => {
    if (isBusy) return; 
    isBusy = true; 
    try {
        const payload = await fetchAIData();
        await executeBets(payload);
    } catch (e) {
        addLogEntry('❌ Error: ' + e.message);
    }
    isBusy = false; 
}, POLLING_INTERVAL_MS);